-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 03, 2022 at 03:49 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `doctor123`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminlogin`
--

CREATE TABLE `adminlogin` (
  `sl no` int(11) NOT NULL,
  `id` text NOT NULL,
  `pass` text NOT NULL,
  `cpass` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `adminlogin`
--

INSERT INTO `adminlogin` (`sl no`, `id`, `pass`, `cpass`) VALUES
(1, 'guptaom782@gmail.com', '12345', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `s.no` int(11) NOT NULL,
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `dname` varchar(30) NOT NULL,
  `e-mail` varchar(20) NOT NULL,
  `phone_no` text NOT NULL,
  `dob` date NOT NULL,
  `age` text NOT NULL,
  `filename` varchar(100) NOT NULL,
  `gender` text NOT NULL,
  `vtime` text NOT NULL,
  `fess` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`s.no`, `first_name`, `last_name`, `dname`, `e-mail`, `phone_no`, `dob`, `age`, `filename`, `gender`, `vtime`, `fess`) VALUES
(1, 'OM', 'GUPTA', 'subrata567@gamil.com', 'guptaom782@gmail.com', '6289330656', '2000-06-21', '21', 'new.jpg', 'male', '12:30pm-3:00pm', 784);

-- --------------------------------------------------------

--
-- Table structure for table `contact123`
--

CREATE TABLE `contact123` (
  `sl no` int(20) NOT NULL,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `number` int(11) NOT NULL,
  `description` varchar(200) NOT NULL,
  `state` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact123`
--

INSERT INTO `contact123` (`sl no`, `name`, `email`, `number`, `description`, `state`) VALUES
(1, 'om gupta', 'gupta123@gmail.com', 82836724, 'Hello world!', 'westbengal'),
(7, 'shayaman roy', ' sham1567@gmail.com', 2147483647, 'Hello owner', ' Karnataka'),
(13, 'Om Gupta', ' guptaom782@gmail.com', 2147483647, 'Hi', ' West Bengal'),
(18, 'Urvesh Pal', ' urveshpal2018@gmail.com', 2147483647, 'I am a enterpurner', ' West Bengal'),
(19, 'Om Gupta', ' guptaom782@gmail.com', 2147483647, 'zbmbxzb', ' West Bengal'),
(20, 'Om Gupta', ' guptaom782@gmail.com', 2147483647, 'zbmbxzb', ' West Bengal'),
(21, 'Om Gupta', ' guptaom782@gmail.com', 2147483647, 'zbmbxzb', ' West Bengal'),
(22, 'Om Gupta', ' guptaom782@gmail.com', 2147483647, 'zbmbxzb', ' West Bengal'),
(23, 'Om Gupta', ' guptaom782@gmail.com', 2147483647, 'zbmbxzb', ' West Bengal'),
(24, 'Om Gupta', ' guptaom782@gmail.com', 2147483647, 'zbmbxzb', ' West Bengal'),
(25, 'Om Gupta', ' guptaom782@gmail.com', 2147483647, 'zbmbxzb', ' West Bengal'),
(26, 'Om Gupta', ' guptaom782@gmail.com', 2147483647, 'zbmbxzb', ' West Bengal'),
(27, 'Om Gupta', ' guptaom782@gmail.com', 2147483647, 'zbmbxzb', ' West Bengal'),
(28, 'Om Gupta', ' guptaom782@gmail.com', 2147483647, 'zbmbxzb', ' West Bengal'),
(29, 'Om Gupta', ' guptaom782@gmail.com', 2147483647, 'zbmbxzb', ' West Bengal'),
(30, 'Om Gupta', ' guptaom782@gmail.com', 2147483647, 'zbmbxzb', ' West Bengal');

-- --------------------------------------------------------

--
-- Table structure for table `doctor123`
--

CREATE TABLE `doctor123` (
  `s.no` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `address` text NOT NULL,
  `contact` varchar(10) NOT NULL,
  `email` text NOT NULL,
  `category` text NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctor123`
--

INSERT INTO `doctor123` (`s.no`, `id`, `name`, `address`, `contact`, `email`, `category`, `date`) VALUES
(2, 1001, 'somojit karmakar', 'naihati', '933052565', 'test@gmail.com', 'bone', '2021-11-23 20:10:34'),
(3, 1002, 'Sayan Roy', 'Kolkata', '9674793386', 'roysayan846@gmail.com', 'MentalHealth', '2021-11-23 20:13:07'),
(4, 1003, 'Om Gupta', 'naihati', '+916289330', 'guptaom782@gmail.com', 'heart', '2021-11-23 20:15:42'),
(5, 1004, 'Anwesha Chaterjee', 'chinsura', '0628933065', 'anweha57@gmail.com', 'MentalHealth', '2021-11-23 20:18:02'),
(6, 1005, 'manish', 'naihati', '0628933065', 'manish123@gmail.com', 'bone', '2021-11-23 20:19:01'),
(7, 1006, 'Uevesh Pal', 'Kolkata', '8617257949', 'urveshpal2018@gmail.com', 'Surgery', '2021-11-24 13:06:10'),
(8, 1007, 'anil', 'bidhanagar', '245452454', 'om21062000@gmail.com', 'MentalHealth', '2021-11-24 13:09:13');

-- --------------------------------------------------------

--
-- Table structure for table `doctoradd`
--

CREATE TABLE `doctoradd` (
  `sl no` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` text NOT NULL,
  `number` int(11) NOT NULL,
  `exp` varchar(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `vtime` text NOT NULL,
  `certificate` varchar(20) NOT NULL,
  `spec` varchar(20) NOT NULL,
  `photo` varchar(20) NOT NULL,
  `fees` int(20) NOT NULL,
  `total_pay` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctoradd`
--

INSERT INTO `doctoradd` (`sl no`, `name`, `email`, `number`, `exp`, `address`, `vtime`, `certificate`, `spec`, `photo`, `fees`, `total_pay`) VALUES
(56, 'subrata Gosh', 'subrata567@gmail.com', 2147483647, '(2-5)years', '139 rbc road', '12.00pm-3.00pm', '????\0JFIF\0\0\0\0\0\0', 'Cardiologist', '????\0JFIF\0\0\0\0\0\0', 700, 784),
(57, 'Sojit karmakar', 'soumojit.karmakar@gmail.com', 2147483647, '(2-5)years', '139 rbc road', '12.00pm-3.00pm', '????\0JFIF\0,,\0\0', 'Ginologist', '????\0JFIF\0,,\0\0', 700, 784);

-- --------------------------------------------------------

--
-- Table structure for table `doctorlogin`
--

CREATE TABLE `doctorlogin` (
  `sl no` int(11) NOT NULL,
  `id` text NOT NULL,
  `pass` text NOT NULL,
  `cpass` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctorlogin`
--

INSERT INTO `doctorlogin` (`sl no`, `id`, `pass`, `cpass`) VALUES
(54, 'subrata567@gmail.com', '12345', '12345'),
(95, 'soumojit.karmakar@gmail.com', '123', '123'),
(96, 'ranoso123@gamil.com', '123', '123');

-- --------------------------------------------------------

--
-- Table structure for table `signup234`
--

CREATE TABLE `signup234` (
  `s.no` int(11) NOT NULL,
  `user` text NOT NULL,
  `upassword` varchar(8) NOT NULL,
  `cpassword` varchar(8) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `transctiondetail`
--

CREATE TABLE `transctiondetail` (
  `sl` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `dname` varchar(200) NOT NULL,
  `cardnumber` int(20) NOT NULL,
  `cvv` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transctiondetail`
--

INSERT INTO `transctiondetail` (`sl`, `name`, `dname`, `cardnumber`, `cvv`) VALUES
(40, 'guptaom782@gmail.com', 'subrata567@gmail.com', 784, 0);

-- --------------------------------------------------------

--
-- Table structure for table `userlogin`
--

CREATE TABLE `userlogin` (
  `sl no` int(11) NOT NULL,
  `id` text NOT NULL,
  `pass` text NOT NULL,
  `cpass` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `userlogin`
--

INSERT INTO `userlogin` (`sl no`, `id`, `pass`, `cpass`) VALUES
(10, 'guptaom782@gmail.com', '1234', '1234');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminlogin`
--
ALTER TABLE `adminlogin`
  ADD PRIMARY KEY (`sl no`);

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`s.no`);

--
-- Indexes for table `contact123`
--
ALTER TABLE `contact123`
  ADD PRIMARY KEY (`sl no`);

--
-- Indexes for table `doctor123`
--
ALTER TABLE `doctor123`
  ADD PRIMARY KEY (`s.no`);

--
-- Indexes for table `doctoradd`
--
ALTER TABLE `doctoradd`
  ADD PRIMARY KEY (`sl no`);

--
-- Indexes for table `doctorlogin`
--
ALTER TABLE `doctorlogin`
  ADD PRIMARY KEY (`sl no`);

--
-- Indexes for table `signup234`
--
ALTER TABLE `signup234`
  ADD PRIMARY KEY (`s.no`);

--
-- Indexes for table `transctiondetail`
--
ALTER TABLE `transctiondetail`
  ADD PRIMARY KEY (`sl`);

--
-- Indexes for table `userlogin`
--
ALTER TABLE `userlogin`
  ADD PRIMARY KEY (`sl no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adminlogin`
--
ALTER TABLE `adminlogin`
  MODIFY `sl no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `s.no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT for table `contact123`
--
ALTER TABLE `contact123`
  MODIFY `sl no` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `doctor123`
--
ALTER TABLE `doctor123`
  MODIFY `s.no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `doctoradd`
--
ALTER TABLE `doctoradd`
  MODIFY `sl no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `doctorlogin`
--
ALTER TABLE `doctorlogin`
  MODIFY `sl no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=97;

--
-- AUTO_INCREMENT for table `signup234`
--
ALTER TABLE `signup234`
  MODIFY `s.no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `transctiondetail`
--
ALTER TABLE `transctiondetail`
  MODIFY `sl` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `userlogin`
--
ALTER TABLE `userlogin`
  MODIFY `sl no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
