-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 03, 2022 at 03:50 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `doctor123`
--

-- --------------------------------------------------------

--
-- Table structure for table `doctoradd`
--

CREATE TABLE `doctoradd` (
  `sl no` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` text NOT NULL,
  `number` int(11) NOT NULL,
  `exp` varchar(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `vtime` text NOT NULL,
  `certificate` varchar(20) NOT NULL,
  `spec` varchar(20) NOT NULL,
  `photo` varchar(20) NOT NULL,
  `fees` int(20) NOT NULL,
  `total_pay` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctoradd`
--

INSERT INTO `doctoradd` (`sl no`, `name`, `email`, `number`, `exp`, `address`, `vtime`, `certificate`, `spec`, `photo`, `fees`, `total_pay`) VALUES
(56, 'subrata Gosh', 'subrata567@gmail.com', 2147483647, '(2-5)years', '139 rbc road', '12.00pm-3.00pm', '????\0JFIF\0\0\0\0\0\0', 'Cardiologist', '????\0JFIF\0\0\0\0\0\0', 700, 784),
(57, 'Sojit karmakar', 'soumojit.karmakar@gmail.com', 2147483647, '(2-5)years', '139 rbc road', '12.00pm-3.00pm', '????\0JFIF\0,,\0\0', 'Ginologist', '????\0JFIF\0,,\0\0', 700, 784);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `doctoradd`
--
ALTER TABLE `doctoradd`
  ADD PRIMARY KEY (`sl no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `doctoradd`
--
ALTER TABLE `doctoradd`
  MODIFY `sl no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
